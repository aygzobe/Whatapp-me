"""
Database models for each tenant's isolated database.

Every tenant database (ayg_builders_business_<id>) contains these tables.
Models are shared — the session determines which database is queried.
"""
from datetime import datetime

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
)
from sqlalchemy.orm import DeclarativeBase, relationship
from sqlalchemy.sql import func


class Base(DeclarativeBase):
    pass


# ---------------------------------------------------------------------------
# Business profile — one row per tenant database
# ---------------------------------------------------------------------------

class BusinessProfile(Base):
    __tablename__ = "business_profiles"

    id            = Column(Integer, primary_key=True, index=True)
    business_name = Column(String(255), nullable=False)
    email         = Column(String(255), nullable=False, unique=True)
    phone         = Column(String(50), nullable=True)
    address       = Column(Text, nullable=True)
    city          = Column(String(100), nullable=True)
    country       = Column(String(100), nullable=False, default="Ghana")
    is_active     = Column(Boolean, nullable=False, default=True)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    products  = relationship("Product",  back_populates="business", cascade="all, delete-orphan")
    customers = relationship("Customer", back_populates="business", cascade="all, delete-orphan")
    orders    = relationship("Order",    back_populates="business", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<BusinessProfile id={self.id} name={self.business_name!r}>"


# ---------------------------------------------------------------------------
# Products / inventory
# ---------------------------------------------------------------------------

class Product(Base):
    __tablename__ = "products"

    id          = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profiles.id"), nullable=False)
    name        = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    price       = Column(Numeric(10, 2), nullable=False)
    stock_qty   = Column(Integer, nullable=False, default=0)
    sku         = Column(String(100), nullable=True, unique=True)
    is_active   = Column(Boolean, nullable=False, default=True)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())

    business    = relationship("BusinessProfile", back_populates="products")
    order_items = relationship("OrderItem", back_populates="product")

    def __repr__(self) -> str:
        return f"<Product id={self.id} name={self.name!r} price={self.price}>"


# ---------------------------------------------------------------------------
# Customers
# ---------------------------------------------------------------------------

class Customer(Base):
    __tablename__ = "customers"

    id          = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profiles.id"), nullable=False)
    full_name   = Column(String(255), nullable=False)
    email       = Column(String(255), nullable=True)
    phone       = Column(String(50), nullable=True)
    address     = Column(Text, nullable=True)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())

    business = relationship("BusinessProfile", back_populates="customers")
    orders   = relationship("Order", back_populates="customer")

    def __repr__(self) -> str:
        return f"<Customer id={self.id} name={self.full_name!r}>"


# ---------------------------------------------------------------------------
# Orders + line items
# ---------------------------------------------------------------------------

class Order(Base):
    __tablename__ = "orders"

    id          = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profiles.id"), nullable=False)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=True)
    status      = Column(String(50), nullable=False, default="pending")
    # pending | confirmed | shipped | delivered | cancelled
    total_amount = Column(Numeric(10, 2), nullable=False, default=0)
    notes        = Column(Text, nullable=True)
    created_at   = Column(DateTime(timezone=True), server_default=func.now())
    updated_at   = Column(DateTime(timezone=True), onupdate=func.now())

    business = relationship("BusinessProfile", back_populates="orders")
    customer = relationship("Customer",        back_populates="orders")
    items    = relationship("OrderItem",       back_populates="order", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Order id={self.id} status={self.status!r} total={self.total_amount}>"


class OrderItem(Base):
    __tablename__ = "order_items"

    id         = Column(Integer, primary_key=True, index=True)
    order_id   = Column(Integer, ForeignKey("orders.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    quantity   = Column(Integer, nullable=False, default=1)
    unit_price = Column(Numeric(10, 2), nullable=False)  # snapshot at time of order

    order   = relationship("Order",   back_populates="items")
    product = relationship("Product", back_populates="order_items")

    def __repr__(self) -> str:
        return f"<OrderItem order={self.order_id} product={self.product_id} qty={self.quantity}>"
