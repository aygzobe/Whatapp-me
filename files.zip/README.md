# AYG Builders API

Multi-tenant SaaS backend for Ghanaian builders and suppliers.
Each business gets a fully isolated PostgreSQL database, authenticated via JWT.

---

## Project structure

```
ayg_builders/
├── main.py                  # FastAPI app entry point
├── db_setup.py              # Provision tenant databases + seed data
├── generate_tokens.py       # Dev utility: mint JWT tokens
├── tenants/
│   └── manager.py           # Thread-safe tenant session factory
└── business/
    ├── api.py               # JWT auth + DB session dependencies
    ├── models.py            # SQLAlchemy ORM models
    ├── schemas.py           # Pydantic request/response schemas
    ├── crud.py              # Database operations
    └── routes.py            # FastAPI route handlers
requirements.txt
railway.toml                 # Railway deployment config
render.yaml                  # Render deployment config
.env.example                 # Environment variable template
```

---

## Local setup

### 1. Clone and install

```bash
git clone <your-repo>
cd ayg_builders
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env — set DATABASE_URL and JWT_SECRET
```

Generate a secure JWT secret:
```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

### 3. Start PostgreSQL

Local PostgreSQL must be running. The `DATABASE_URL` in `.env` should point to it.
Free cloud options: [Neon](https://neon.tech) or [Supabase](https://supabase.com) — both have free tiers and work without local Postgres.

### 4. Provision tenant databases

```bash
python -m ayg_builders.db_setup
```

This creates `ayg_builders_business_1` and `ayg_builders_business_2`, builds all tables, and seeds starter profiles.

### 5. Start the server

```bash
uvicorn ayg_builders.main:app --reload --host 0.0.0.0 --port 8000
```

API docs available at: http://localhost:8000/docs

### 6. Generate dev tokens

```bash
JWT_SECRET=your_secret python -m ayg_builders.generate_tokens
```

---

## Test from your phone

1. Find your PC's local IP: `ipconfig` (Windows) or `ifconfig` (Mac/Linux)
2. Make sure your phone is on the same WiFi network
3. Install [HTTPie](https://httpie.io/app) or [Insomnia](https://insomnia.rest) on your phone
4. Hit: `http://YOUR_PC_IP:8000/api/v1/business/profile`
   with header: `Authorization: Bearer <token from step 6>`

---

## API reference

All routes require `Authorization: Bearer <token>` except `/health`.

### Profile
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/business/profile` | Get business profile |
| PATCH | `/api/v1/business/profile` | Update profile fields |

### Products
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/business/products` | List products |
| GET | `/api/v1/business/products/{id}` | Get single product |
| POST | `/api/v1/business/products` | Create product |

### Customers
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/business/customers` | List customers |
| POST | `/api/v1/business/customers` | Create customer |

### Orders
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/business/orders` | List orders (filter by status) |
| POST | `/api/v1/business/orders` | Create order with line items |
| PATCH | `/api/v1/business/orders/{id}/status` | Update order status |

---

## Deploy to Railway

1. Push your code to GitHub
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Add a PostgreSQL plugin (Railway provides one free)
4. Set environment variables in Railway dashboard:
   - `DATABASE_URL` — Railway auto-injects this if you use their Postgres plugin
   - `JWT_SECRET` — generate with `python -c "import secrets; print(secrets.token_hex(32))"`
5. After first deploy, run the provisioning script once via Railway's shell:
   ```bash
   python -m ayg_builders.db_setup
   ```
6. Your API is live at `https://your-app.up.railway.app`

## Deploy to Render

1. Push your code to GitHub
2. Go to [render.com](https://render.com) → New → Web Service → connect your repo
3. Render auto-detects `render.yaml`
4. Add a PostgreSQL database in Render dashboard (free tier available)
5. Set `DATABASE_URL` in environment variables to your Render Postgres connection string
6. After deploy, open the Render shell and run:
   ```bash
   python -m ayg_builders.db_setup
   ```
7. Your API is live at `https://your-app.onrender.com`

---

## Tenant isolation — how it works

Each tenant authenticates with a JWT containing their `tenant_id`.
The `get_tenant_db` dependency decodes the token and routes every database
operation to an isolated PostgreSQL database (`ayg_builders_business_<id>`).
Business 1 cannot read or write Business 2's data — they never share a connection.

```
Bearer JWT (tenant_id=1)
        ↓
  jwt.decode() + validation
        ↓
  get_tenant_session_factory("1")
        ↓
  ayg_builders_business_1  ←── isolated DB
```
