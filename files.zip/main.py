"""
AYG Builders — FastAPI application entry point.

Start locally:
    uvicorn ayg_builders.main:app --reload --host 0.0.0.0 --port 8000

Production (Railway / Render):
    uvicorn ayg_builders.main:app --host 0.0.0.0 --port $PORT
"""
import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from ayg_builders.business.routes import router as business_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup / shutdown hooks."""
    logger.info("AYG Builders API starting up…")
    # Validate required env vars early — crash loudly rather than at first request
    required = ["DATABASE_URL", "JWT_SECRET"]
    missing = [k for k in required if not os.getenv(k)]
    if missing:
        raise RuntimeError(f"Missing required environment variables: {missing}")
    yield
    logger.info("AYG Builders API shutting down…")


app = FastAPI(
    title="AYG Builders API",
    description="Multi-tenant SaaS backend for Ghanaian builders & suppliers.",
    version="1.0.0",
    lifespan=lifespan,
)

# ---------------------------------------------------------------------------
# CORS — tighten ALLOW_ORIGINS in production
# ---------------------------------------------------------------------------
ALLOW_ORIGINS = os.getenv("ALLOW_ORIGINS", "*").split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOW_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Global exception handler — never leak stack traces to clients
# ---------------------------------------------------------------------------
@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled error on %s %s", request.method, request.url)
    return JSONResponse(
        status_code=500,
        content={"detail": "An unexpected error occurred. Please try again later."},
    )


# ---------------------------------------------------------------------------
# Routers
# ---------------------------------------------------------------------------
app.include_router(business_router)


# ---------------------------------------------------------------------------
# Root — quick confirmation the server is alive
# ---------------------------------------------------------------------------
@app.get("/", include_in_schema=False)
def root():
    return {"message": "AYG Builders API is running.", "docs": "/docs"}
