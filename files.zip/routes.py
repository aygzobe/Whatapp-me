"""
Business routes — all endpoints mounted under /api/v1/business.
Every route is tenant-isolated via the get_tenant_db dependency.
"""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ayg_builders.business import crud, schemas
from ayg_builders.business.api import get_current_tenant_id, get_tenant_db

router = APIRouter(
    prefix="/api/v1/business",
    tags=["Business"],
)


# ---------------------------------------------------------------------------
# Profile
# ---------------------------------------------------------------------------

@router.get(
    "/profile",
    response_model=schemas.BusinessProfileResponse,
    summary="Get the authenticated tenant's business profile",
)
def get_business_profile(db: Session = Depends(get_tenant_db)):
    profile = crud.get_profile(db)
    if profile is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Business profile not found.",
        )
    return profile


@router.patch(
    "/profile",
    response_model=schemas.BusinessProfileResponse,
    summary="Update business profile fields",
)
def update_business_profile(
    updates: schemas.BusinessProfileUpdate,
    db: Session = Depends(get_tenant_db),
):
    profile = crud.update_profile(db, updates)
    if profile is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Business profile not found.",
        )
    return profile


# ---------------------------------------------------------------------------
# Products
# ---------------------------------------------------------------------------

@router.get(
    "/products",
    response_model=list[schemas.ProductResponse],
    summary="List all products for this tenant",
)
def list_products(
    skip:        int  = Query(0,    ge=0),
    limit:       int  = Query(50,   ge=1, le=200),
    active_only: bool = Query(True),
    db: Session = Depends(get_tenant_db),
):
    return crud.get_products(db, skip=skip, limit=limit, active_only=active_only)


@router.get(
    "/products/{product_id}",
    response_model=schemas.ProductResponse,
    summary="Get a single product by ID",
)
def get_product(product_id: int, db: Session = Depends(get_tenant_db)):
    product = crud.get_product(db, product_id)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found.")
    return product


@router.post(
    "/products",
    response_model=schemas.ProductResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new product",
)
def create_product(
    product: schemas.ProductCreate,
    db: Session = Depends(get_tenant_db),
):
    profile = crud.get_profile(db)
    if profile is None:
        raise HTTPException(status_code=404, detail="Business profile not found.")
    return crud.create_product(db, product, business_id=profile.id)


# ---------------------------------------------------------------------------
# Customers
# ---------------------------------------------------------------------------

@router.get(
    "/customers",
    response_model=list[schemas.CustomerResponse],
    summary="List all customers for this tenant",
)
def list_customers(
    skip:  int = Query(0,  ge=0),
    limit: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_tenant_db),
):
    return crud.get_customers(db, skip=skip, limit=limit)


@router.post(
    "/customers",
    response_model=schemas.CustomerResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new customer",
)
def create_customer(
    customer: schemas.CustomerCreate,
    db: Session = Depends(get_tenant_db),
):
    profile = crud.get_profile(db)
    if profile is None:
        raise HTTPException(status_code=404, detail="Business profile not found.")
    return crud.create_customer(db, customer, business_id=profile.id)


# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------

@router.get(
    "/orders",
    response_model=list[schemas.OrderResponse],
    summary="List orders, optionally filtered by status",
)
def list_orders(
    skip:   int            = Query(0,    ge=0),
    limit:  int            = Query(50,   ge=1, le=200),
    status: Optional[str]  = Query(None, description="Filter by status: pending|confirmed|shipped|delivered|cancelled"),
    db: Session = Depends(get_tenant_db),
):
    return crud.get_orders(db, skip=skip, limit=limit, status=status)


@router.post(
    "/orders",
    response_model=schemas.OrderResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new order with line items",
)
def create_order(
    order: schemas.OrderCreate,
    db: Session = Depends(get_tenant_db),
):
    profile = crud.get_profile(db)
    if profile is None:
        raise HTTPException(status_code=404, detail="Business profile not found.")
    try:
        return crud.create_order(db, order, business_id=profile.id)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc))


@router.patch(
    "/orders/{order_id}/status",
    response_model=schemas.OrderResponse,
    summary="Update an order's status",
)
def update_order_status(
    order_id: int,
    new_status: str,
    db: Session = Depends(get_tenant_db),
):
    try:
        order = crud.update_order_status(db, order_id, new_status)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc))
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found.")
    return order


# ---------------------------------------------------------------------------
# Health check (unauthenticated — used by Railway / Render)
# ---------------------------------------------------------------------------

@router.get(
    "/health",
    tags=["Health"],
    summary="Liveness check — no auth required",
    include_in_schema=False,
)
def health():
    return {"status": "ok"}
