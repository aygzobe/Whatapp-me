"""
FastAPI dependencies — auth and database session injection.
These wire JWT → tenant_id → isolated DB session for every protected route.
"""
import datetime
import os

import jwt
from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from ayg_builders.tenants.manager import get_tenant_session_factory

# Fail loudly at startup if secret is missing — never fall back to a weak default
JWT_SECRET    = os.environ["JWT_SECRET"]
JWT_ALGORITHM = "HS256"
JWT_LEEWAY    = datetime.timedelta(seconds=10)  # tolerates minor clock skew

security = HTTPBearer()


def get_current_tenant_id(
    credentials: HTTPAuthorizationCredentials = Security(security),
) -> str:
    """
    Extracts and validates the Bearer JWT.
    Returns tenant_id on success; raises 401 on any failure.
    """
    token = credentials.credentials
    try:
        payload = jwt.decode(
            token,
            JWT_SECRET,
            algorithms=[JWT_ALGORITHM],
            leeway=JWT_LEEWAY,
            options={"require": ["exp", "tenant_id"]},  # both claims mandatory
        )
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return payload["tenant_id"]  # safe — "require" above guarantees presence


def get_tenant_db(
    tenant_id: str = Depends(get_current_tenant_id),
) -> Session:
    """
    Yields an isolated SQLAlchemy session for the authenticated tenant's database.
    Commits on clean exit, rolls back on any exception, always closes.
    """
    SessionLocal = get_tenant_session_factory(tenant_id)
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
