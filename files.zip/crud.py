"""
CRUD layer — all database reads and writes live here.
Routes stay thin; business logic stays out of models.
"""
from decimal import Decimal
from typing import Optional

from sqlalchemy.orm import Session

from ayg_builders.business import models, schemas


# ---------------------------------------------------------------------------
# Business profile
# ---------------------------------------------------------------------------

def get_profile(db: Session) -> Optional[models.BusinessProfile]:
    """Returns the single business profile row for this tenant's database."""
    return db.query(models.BusinessProfile).first()


def update_profile(
    db: Session,
    updates: schemas.BusinessProfileUpdate,
) -> Optional[models.BusinessProfile]:
    profile = get_profile(db)
    if profile is None:
        return None
    for field, value in updates.model_dump(exclude_none=True).items():
        setattr(profile, field, value)
    db.flush()
    return profile


# ---------------------------------------------------------------------------
# Products
# ---------------------------------------------------------------------------

def get_products(
    db: Session,
    skip: int = 0,
    limit: int = 50,
    active_only: bool = True,
) -> list[models.Product]:
    q = db.query(models.Product)
    if active_only:
        q = q.filter(models.Product.is_active == True)  # noqa: E712
    return q.offset(skip).limit(limit).all()


def get_product(db: Session, product_id: int) -> Optional[models.Product]:
    return db.query(models.Product).filter(models.Product.id == product_id).first()


def create_product(
    db: Session,
    product: schemas.ProductCreate,
    business_id: int,
) -> models.Product:
    db_product = models.Product(**product.model_dump(), business_id=business_id)
    db.add(db_product)
    db.flush()
    return db_product


# ---------------------------------------------------------------------------
# Customers
# ---------------------------------------------------------------------------

def get_customers(
    db: Session,
    skip: int = 0,
    limit: int = 50,
) -> list[models.Customer]:
    return db.query(models.Customer).offset(skip).limit(limit).all()


def get_customer(db: Session, customer_id: int) -> Optional[models.Customer]:
    return db.query(models.Customer).filter(models.Customer.id == customer_id).first()


def create_customer(
    db: Session,
    customer: schemas.CustomerCreate,
    business_id: int,
) -> models.Customer:
    db_customer = models.Customer(**customer.model_dump(), business_id=business_id)
    db.add(db_customer)
    db.flush()
    return db_customer


# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------

def get_orders(
    db: Session,
    skip: int = 0,
    limit: int = 50,
    status: Optional[str] = None,
) -> list[models.Order]:
    q = db.query(models.Order)
    if status:
        q = q.filter(models.Order.status == status)
    return q.order_by(models.Order.created_at.desc()).offset(skip).limit(limit).all()


def get_order(db: Session, order_id: int) -> Optional[models.Order]:
    return db.query(models.Order).filter(models.Order.id == order_id).first()


def create_order(
    db: Session,
    order: schemas.OrderCreate,
    business_id: int,
) -> models.Order:
    """
    Creates an order and its line items in one transaction.
    Calculates total from product prices at time of order (unit_price snapshot).
    """
    total = Decimal("0")
    items_data = []

    for item in order.items:
        product = get_product(db, item.product_id)
        if product is None:
            raise ValueError(f"Product {item.product_id} not found")
        if product.stock_qty < item.quantity:
            raise ValueError(
                f"Insufficient stock for {product.name!r}: "
                f"requested {item.quantity}, available {product.stock_qty}"
            )
        line_total = product.price * item.quantity
        total += line_total
        items_data.append((product, item.quantity, product.price))

    db_order = models.Order(
        business_id=business_id,
        customer_id=order.customer_id,
        notes=order.notes,
        total_amount=total,
    )
    db.add(db_order)
    db.flush()  # get db_order.id before adding items

    for product, qty, unit_price in items_data:
        db.add(models.OrderItem(
            order_id=db_order.id,
            product_id=product.id,
            quantity=qty,
            unit_price=unit_price,
        ))
        # Decrement stock
        product.stock_qty -= qty

    db.flush()
    return db_order


def update_order_status(
    db: Session,
    order_id: int,
    status: str,
) -> Optional[models.Order]:
    allowed = {"pending", "confirmed", "shipped", "delivered", "cancelled"}
    if status not in allowed:
        raise ValueError(f"Invalid status {status!r}. Must be one of {allowed}")
    order = get_order(db, order_id)
    if order:
        order.status = status
        db.flush()
    return order
