import os
import re
import threading

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Base PostgreSQL URL — set DATABASE_URL in your .env / Railway / Render env vars
# Format: postgresql://user:password@host:5432/postgres
BASE_DB_URL = os.environ["DATABASE_URL"]

# In-memory cache: tenant_id → session factory
_tenant_sessions: dict = {}
_lock = threading.Lock()

# Strict allowlist — only alphanumeric, underscore, hyphen
_VALID_TENANT_ID = re.compile(r"^[a-zA-Z0-9_-]+$")


def _validate_tenant_id(tenant_id: str) -> None:
    """Guards against SQL injection / path traversal in the DB name."""
    if not _VALID_TENANT_ID.match(tenant_id):
        raise ValueError(f"Invalid tenant_id: {tenant_id!r}")


def get_tenant_session_factory(tenant_id: str):
    """
    Returns a SQLAlchemy session factory bound to the tenant's database.
    Uses double-checked locking so concurrent requests never race on engine creation.
    """
    _validate_tenant_id(tenant_id)

    # Fast path — no lock needed if already cached
    if tenant_id in _tenant_sessions:
        return _tenant_sessions[tenant_id]

    with _lock:
        # Re-check inside the lock in case another thread just populated it
        if tenant_id not in _tenant_sessions:
            # Strip the database name from BASE_DB_URL and replace with tenant DB
            base = BASE_DB_URL.rsplit("/", 1)[0]
            tenant_db_url = f"{base}/ayg_builders_business_{tenant_id}"

            engine = create_engine(
                tenant_db_url,
                pool_size=5,
                max_overflow=10,
                pool_pre_ping=True,   # reconnects dropped connections automatically
            )
            _tenant_sessions[tenant_id] = sessionmaker(
                autocommit=False,
                autoflush=False,
                bind=engine,
            )

    return _tenant_sessions[tenant_id]


def dispose_tenant(tenant_id: str) -> None:
    """
    Disposes the engine and removes the cached session factory for a tenant.
    Call this when offboarding a tenant or in tests between runs.
    """
    with _lock:
        factory = _tenant_sessions.pop(tenant_id, None)
        if factory and factory.kw.get("bind"):
            factory.kw["bind"].dispose()
