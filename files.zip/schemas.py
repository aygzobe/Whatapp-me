"""
Pydantic schemas — controls exactly what enters and leaves the API.
The response models act as a whitelist: only declared fields are serialized,
so internal columns (flags, audit fields) never leak accidentally.
"""
from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel, EmailStr, field_validator


# ---------------------------------------------------------------------------
# Business profile
# ---------------------------------------------------------------------------

class BusinessProfileResponse(BaseModel):
    id:            int
    business_name: str
    email:         EmailStr
    phone:         Optional[str] = None
    address:       Optional[str] = None
    city:          Optional[str] = None
    country:       str
    created_at:    datetime

    model_config = {"from_attributes": True}


class BusinessProfileUpdate(BaseModel):
    business_name: Optional[str]  = None
    phone:         Optional[str]  = None
    address:       Optional[str]  = None
    city:          Optional[str]  = None


# ---------------------------------------------------------------------------
# Products
# ---------------------------------------------------------------------------

class ProductBase(BaseModel):
    name:        str
    description: Optional[str]     = None
    price:       Decimal
    stock_qty:   int               = 0
    sku:         Optional[str]     = None

    @field_validator("price")
    @classmethod
    def price_must_be_positive(cls, v: Decimal) -> Decimal:
        if v < 0:
            raise ValueError("Price must be non-negative")
        return v


class ProductCreate(ProductBase):
    pass


class ProductResponse(ProductBase):
    id:         int
    is_active:  bool
    created_at: datetime

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Customers
# ---------------------------------------------------------------------------

class CustomerCreate(BaseModel):
    full_name: str
    email:     Optional[EmailStr] = None
    phone:     Optional[str]      = None
    address:   Optional[str]      = None


class CustomerResponse(CustomerCreate):
    id:         int
    created_at: datetime

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------

class OrderItemCreate(BaseModel):
    product_id: int
    quantity:   int = 1

    @field_validator("quantity")
    @classmethod
    def qty_must_be_positive(cls, v: int) -> int:
        if v < 1:
            raise ValueError("Quantity must be at least 1")
        return v


class OrderCreate(BaseModel):
    customer_id: Optional[int] = None
    notes:       Optional[str] = None
    items:       list[OrderItemCreate]


class OrderItemResponse(BaseModel):
    id:         int
    product_id: int
    quantity:   int
    unit_price: Decimal

    model_config = {"from_attributes": True}


class OrderResponse(BaseModel):
    id:           int
    customer_id:  Optional[int]
    status:       str
    total_amount: Decimal
    notes:        Optional[str]
    created_at:   datetime
    items:        list[OrderItemResponse] = []

    model_config = {"from_attributes": True}
