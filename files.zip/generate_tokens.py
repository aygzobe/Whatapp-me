"""
Dev utility — generates short-lived JWTs for local testing.

Usage:
    JWT_SECRET=your_secret python -m ayg_builders.generate_tokens

Never commit real secrets. Add this file to .gitignore if needed.
"""
import datetime
import os
import sys

import jwt

SECRET = os.environ.get("JWT_SECRET")
if not SECRET:
    print("✗ JWT_SECRET environment variable is not set.")
    sys.exit(1)

ALGO           = "HS256"
TOKEN_TTL_MINS = 60

TEST_TENANTS = [
    {"tenant_id": "1", "label": "Shop in Accra"},
    {"tenant_id": "2", "label": "Supplier in Tema"},
]


def generate_token(tenant_id: str) -> str:
    now = datetime.datetime.now(datetime.timezone.utc)
    payload = {
        "tenant_id": tenant_id,
        "iat": now,
        "exp": now + datetime.timedelta(minutes=TOKEN_TTL_MINS),
    }
    return jwt.encode(payload, SECRET, algorithm=ALGO)


if __name__ == "__main__":
    print(f"\n🔑  AYG Builders — Dev Token Generator (TTL: {TOKEN_TTL_MINS}m)\n")
    for t in TEST_TENANTS:
        token = generate_token(t["tenant_id"])
        print(f"--- {t['label']} (tenant_id={t['tenant_id']}) ---")
        print(f"Bearer {token}\n")
