"""
Database provisioning script.

Run once to:
  1. Create each tenant's database (ayg_builders_business_<id>)
  2. Create all tables inside it
  3. Seed a starter business profile

Usage:
    python -m ayg_builders.db_setup

Environment variables required:
    DATABASE_URL  — points to your PostgreSQL server
                    e.g. postgresql://user:pass@host:5432/postgres
"""
import os
import sys

from sqlalchemy import create_engine, text
from sqlalchemy.exc import ProgrammingError

from ayg_builders.business.models import Base, BusinessProfile

# Tenants to provision on first run
TENANTS = [
    {
        "id": "1",
        "profile": {
            "business_name": "Shop in Accra",
            "email": "shop@accra.gh",
            "phone": "+233 30 000 0001",
            "city": "Accra",
            "address": "1 Independence Ave, Accra",
            "country": "Ghana",
        },
    },
    {
        "id": "2",
        "profile": {
            "business_name": "Supplier in Tema",
            "email": "supplier@tema.gh",
            "phone": "+233 22 000 0002",
            "city": "Tema",
            "address": "Tema Industrial Area, Block C",
            "country": "Ghana",
        },
    },
]


def get_admin_engine():
    """
    Engine connected to the default 'postgres' admin database.
    Used only for CREATE DATABASE commands.
    """
    base_url = os.environ["DATABASE_URL"]
    # Replace the database name with 'postgres' for admin operations
    admin_url = base_url.rsplit("/", 1)[0] + "/postgres"
    return create_engine(admin_url, isolation_level="AUTOCOMMIT")


def create_tenant_database(admin_engine, db_name: str) -> bool:
    """Creates the tenant database if it doesn't already exist. Returns True if created."""
    with admin_engine.connect() as conn:
        exists = conn.execute(
            text("SELECT 1 FROM pg_database WHERE datname = :name"),
            {"name": db_name},
        ).fetchone()

        if exists:
            print(f"  ✓ Database '{db_name}' already exists — skipping")
            return False

        conn.execute(text(f'CREATE DATABASE "{db_name}"'))
        print(f"  ✓ Created database '{db_name}'")
        return True


def provision_tenant(tenant: dict):
    """Creates tables and seeds the business profile for one tenant."""
    tid = tenant["id"]
    db_name = f"ayg_builders_business_{tid}"

    base_url = os.environ["DATABASE_URL"].rsplit("/", 1)[0]
    tenant_url = f"{base_url}/{db_name}"

    engine = create_engine(tenant_url)

    # Create all tables
    Base.metadata.create_all(engine)
    print(f"  ✓ Tables created in '{db_name}'")

    # Seed profile if not already present
    from sqlalchemy.orm import sessionmaker
    Session = sessionmaker(bind=engine)
    with Session() as db:
        existing = db.query(BusinessProfile).first()
        if existing:
            print(f"  ✓ Profile already seeded — skipping")
        else:
            db.add(BusinessProfile(**tenant["profile"]))
            db.commit()
            print(f"  ✓ Seeded profile: {tenant['profile']['business_name']}")

    engine.dispose()


def main():
    print("\n🏗  AYG Builders — Database Provisioning\n")

    database_url = os.environ.get("DATABASE_URL")
    if not database_url:
        print("✗ DATABASE_URL environment variable is not set.")
        sys.exit(1)

    admin_engine = get_admin_engine()

    for tenant in TENANTS:
        tid = tenant["id"]
        db_name = f"ayg_builders_business_{tid}"
        print(f"\nTenant {tid} — {tenant['profile']['business_name']}")
        try:
            create_tenant_database(admin_engine, db_name)
            provision_tenant(tenant)
        except ProgrammingError as exc:
            print(f"  ✗ Error provisioning tenant {tid}: {exc}")
            sys.exit(1)

    admin_engine.dispose()
    print("\n✅ All tenants provisioned successfully.\n")


if __name__ == "__main__":
    main()
